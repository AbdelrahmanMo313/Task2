
import 'package:flutter/material.dart';

class PageSport extends StatelessWidget {
  const PageSport ({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Colors.white,
        body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
            Padding(
              padding: EdgeInsets.all(30.0),
              child: Text('Sport',
                style: TextStyle(fontWeight: FontWeight.w600,
                fontSize: 60),
                textScaleFactor: 2,

              ),
            ),
          ],
        ),

      );

  }
}

import 'package:abdelrahman/page_food.dart';
import 'package:abdelrahman/page_idea.dart';
import 'package:abdelrahman/page_music.dart';
import 'package:abdelrahman/page_sport.dart';
import 'package:abdelrahman/page_work.dart';
import 'package:flutter/material.dart';

class CardAbdo extends StatefulWidget {
  final String textM;
  final String textS;
  final IconData iconAbdo;
  final int numPage;

  CardAbdo({
    super.key,
    required this.textM,
    required this.textS,
    required this.iconAbdo,
    required this.numPage,
  });

  @override
  State<CardAbdo> createState() => _CardAbdoState();
}

class _CardAbdoState extends State<CardAbdo> {
  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.all(12.0),
        child: ElevatedButton(
          onPressed: () {
            Navigator.of(context).push(MaterialPageRoute(builder: (context) {
              if (widget.numPage == 0) {
                return PageIdea(); // Replace Page1 with your actual widget class
              } else if (widget.numPage == 1) {
                return PageFood(); // Replace Page2 with your actual widget class
              } else if (widget.numPage ==2){
                return PageWork();// Replace Page3 with your default widget class
            }

                else if (widget.numPage == 3) {
            return PageSport();
            }
                else {
                return PageMusic();
                }
            }
            ));
          },
          child: Container(
            width: MediaQuery.sizeOf(context).width * 0.9,
            height: MediaQuery.sizeOf(context).height * 0.1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(
                      widget.iconAbdo,
                      size: 40,
                      color: Colors.purple,
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.textM,
                            style: TextStyle(
                                fontSize: 32, fontWeight: FontWeight.bold),
                          ),
                          Text(
                            widget.textS,
                            style: TextStyle(fontSize: 15),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Icon(Icons.arrow_forward_ios,),

              ],
            ),
          ),
        ),
  );
  }
}

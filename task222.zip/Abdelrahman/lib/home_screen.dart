
import 'package:abdelrahman/cardAbdo.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int counter=0;
  final List<CardAbdo> cardAbdoList = [
    CardAbdo(textM: 'Idea', textS: 'f1', iconAbdo: Icons.lightbulb_rounded, numPage: 1,),
    CardAbdo(textM: 'Food', textS: 'f2', iconAbdo: Icons.fastfood_outlined,numPage: 2,),
    CardAbdo(textM: 'Work', textS: 'f3', iconAbdo: Icons.newspaper_outlined,numPage: 3,),
    CardAbdo(textM: 'Sport', textS: 'f4', iconAbdo: Icons.sports_martial_arts_rounded,numPage: 4,),
    CardAbdo(textM: 'Music', textS: 'f5', iconAbdo: Icons.music_note_outlined,numPage: 5,),


  ];
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: SafeArea(child:
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [

           Padding(
             padding: const EdgeInsets.all(12.0),
             child: Text('Choose Activity',
             style: TextStyle(
               fontSize: 20,
               fontWeight: FontWeight.w600,
             ),),
           ),


          Expanded(
            child: ListView.builder(
              itemCount: cardAbdoList.length,
              itemBuilder: (context, index) {
                return CardAbdo(textM: cardAbdoList[index].textM, textS: cardAbdoList[index].textS, iconAbdo: cardAbdoList[index].iconAbdo, numPage: index);
              },
            ),
          ),




        ],
      ),


      ),
    );

  }

}

class CardAbdoWidget extends StatelessWidget {
  final CardAbdo cardAbdo;

  CardAbdoWidget({required this.cardAbdo});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: CardAbdo(
        textM: cardAbdo.textM,
        textS: cardAbdo.textS,
        iconAbdo: cardAbdo.iconAbdo,
        numPage: cardAbdo.numPage,
      ),
    );
  }
}






